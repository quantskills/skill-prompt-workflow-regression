"""Operator-only collection of the three named results, not a receipt exporter."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
names = [f'fixed-v7-{i}' for i in range(1, 4)]
with ZipFile(root / 'fixed-v7-results.zip', 'x', ZIP_DEFLATED) as out:
    for i, name in enumerate(names, 1):
        manifest = json.loads((root / name / 'bundle_manifest.json').read_text(encoding='utf-8'))
        archive = root / f'qs_input_v7_{i}.zip'
        if manifest['run_name'] != name or manifest['archive_sha256'] != sha256(archive.read_bytes()).hexdigest():
            raise ValueError(f'Archive does not match {name}')
        with ZipFile(archive) as source:
            for rel in source.namelist():
                # The three archives are frozen by the operator, not authored by EVO.
                if (root / name / 'inputs' / rel).read_bytes() != source.read(rel):
                    raise ValueError(f'Input modified: {name}/{rel}')
        for rel in ('solve.py', 'bundle_manifest.json', 'output/result.json'):
            path = root / name / rel
            if not path.is_file():
                print(f'MISSING {name}/{rel}')
                continue
            if any(p.is_symlink() for p in (path, *path.parents) if p != root):
                raise ValueError(f'Unexpected symlink for {name}/{rel}')
            out.write(path, f'{name}/{rel}')
        print(f'INPUTS_MATCH {name}')
print('Collected named outputs only; no native EVO receipt exported.')
