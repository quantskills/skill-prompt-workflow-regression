import hashlib, shutil, sys
from pathlib import Path
root = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(root))
from qs_bundle_v7 import prepare
run = prepare(root, 'qs_input_v7_1.zip', '069b4e98fb0668086dfe8882cc560dbeb703147f6906f89f302004c5baa9a9fc', 'fixed-v7-1')
with (run / "solve.py").open("xb") as f:
    f.write((run / "inputs/solve_frozen.py").read_bytes())
print(run.name, hashlib.sha256((run / "solve.py").read_bytes()).hexdigest())
run = prepare(root, 'qs_input_v7_2.zip', '0e2bacfa81ebd8a6b0679423fd91a2f486447d94c50ceab5bd765de02dce8e16', 'fixed-v7-2')
with (run / "solve.py").open("xb") as f:
    f.write((run / "inputs/solve_frozen.py").read_bytes())
print(run.name, hashlib.sha256((run / "solve.py").read_bytes()).hexdigest())
run = prepare(root, 'qs_input_v7_3.zip', 'c11450b5c8e46333cadd429a3b1f129348a1c4714556360d3caadefa5d13a507', 'fixed-v7-3')
with (run / "solve.py").open("xb") as f:
    f.write((run / "inputs/solve_frozen.py").read_bytes())
print(run.name, hashlib.sha256((run / "solve.py").read_bytes()).hexdigest())
