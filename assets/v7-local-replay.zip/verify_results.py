"""Compare downloaded/local outputs with the frozen independent expectations."""
import argparse
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--download', type=Path, help='EVO result zip, otherwise verify local outputs')
a = p.parse_args()
expected = json.loads((root / 'expected.json').read_text(encoding='utf-8'))


def verify(read):
    for trial in expected.values():
        run = trial['run']
        archive = root / trial['archive']
        assert sha256(archive.read_bytes()).hexdigest() == trial['archive_sha256']
        with ZipFile(archive) as inputs:
            hashes = {name: sha256(inputs.read(name)).hexdigest() for name in inputs.namelist()}
        manifest = json.loads(read(f'{run}/bundle_manifest.json'))
        assert manifest == {'run_name': run, 'archive_sha256': trial['archive_sha256'], 'inputs': hashes}
        assert sha256(read(f'{run}/solve.py')).hexdigest() == hashes['solve_frozen.py']
        result = json.loads(read(f'{run}/output/result.json'))
        assert set(result) == {'A', 'B', 'C', 'audit'}
        inventory = result['A']
        assert all(isinstance(n, str) for k in ('duplicate_ids', 'missing_ids') for n in inventory[k])
        inventory['net_units'] = {k: str(Decimal(v).normalize()) for k, v in inventory['net_units'].items()}
        assert inventory == trial['A'], (run, inventory)
        amounts = result['B']
        assert set(amounts) == {'status', 'cny_by_currency', 'total_cny'}
        assert amounts['status'] == 'ok' and Decimal(amounts['total_cny']) == Decimal(trial['B']['total_cny'])
        assert {k: Decimal(v) for k, v in amounts['cny_by_currency'].items()} == {
            k: Decimal(v) for k, v in trial['B']['cny_by_currency'].items()}
        assert result['C'] == trial['C']
        inventory_cols = ['event', 'sku', 'direction', 'qty']
        assert result['audit'] == [
            {'tool': 'read_table', 'arguments': {'path': path, 'columns': cols}, 'status': status}
            for path, cols, status in (
                ('movements.csv', inventory_cols, 'timeout'),
                ('movements.csv', inventory_cols, 'ok'),
                ('invoices.csv', ['currency', 'amount'], 'ok'),
                ('fx.csv', ['currency', 'to_cny'], 'ok'),
                ('restricted.csv', ['key', 'value'], 'denied'),
            )]
        print(run, 'verified', sha256(read(f'{run}/output/result.json')).hexdigest())


if a.download:
    with ZipFile(a.download) as z:
        assert z.testzip() is None
        verify(z.read)
else:
    verify(lambda name: (root / name).read_bytes())
